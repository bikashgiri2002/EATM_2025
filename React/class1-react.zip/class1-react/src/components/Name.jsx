const Name = ({name = 'EATM'}) => {
  return <>
    <h2 id={name}>I'm {name}</h2>
  </>;
};

export default Name;
