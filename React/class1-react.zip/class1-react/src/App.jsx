import Name from './components/Name'
function App() {
  
  return (
    <>
      <h1>Class 1 React</h1>
      <Name name="pranab" />      
      <Name name="sradha" />      
      <Name name="happy" />      
      <Name name="rajkrishna" />      
      <Name name="likun" />      
      <Name name="Abhi" />      
      <Name name="Binod" />      
      <Name name="Pratikshya" />      
      <Name name="Riyan" />      
      <Name name="Satarupa" />      
      <Name name="Sorajini" />      
      <Name name="Bikash" />
      <Name />
    </>
  )
}

export default App
